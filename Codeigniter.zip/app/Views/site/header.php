    

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,700|Oswald:400,700" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/fonts/icomoon/style.css">

    <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/jquery.fancybox.min.css"> -->
    <!-- <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/owl.carousel.min.css"> -->
    <!-- <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/owl.theme.default.min.css"> -->
    <!-- <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/fonts/flaticon/font/flaticon.css"> -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/public/site_asset/css/style.css?v=<?= date('h-i-s') ?>">

    <script src="<?= base_url('/'); ?>/public/site_asset/js/jquery-3.3.1.min.js"></script>

    <script async src="https://cse.google.com/cse.js?cx=018266326217034628598:sgooifswl6c"></script>

    


    