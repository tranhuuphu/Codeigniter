﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'fr', {
	clear: 'Effacer',
	highlight: 'Pointée',
	options: 'Options de couleur',
	selected: 'Couleur choisie',
	title: 'Sélectionner une couleur'
} );
